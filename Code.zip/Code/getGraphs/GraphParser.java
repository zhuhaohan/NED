import java.io.*;
import java.util.LinkedList;
import java.util.HashSet;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 *
 * @author Haohan Zhu
 */
public class GraphParser extends DefaultHandler{
    
    private final int maxAuthorsPerPaper = 200;
    
    private String preTag = null;
    private String recordTag;
    private String authorName;
    private LinkedList<String> authors = new LinkedList<String>();
    private int year;
    private String key;

    private DB db;
    private int authorCounts;

    public void startDocument() throws SAXException {
        authorCounts = 0;
        db = new DB();
    }
    
    public void endDocument() throws SAXException {
        System.out.println("Number of Publications with Authos: " + db.sizeofPublications());
        System.out.println("Number of Different Authors: " + db.sizeOfAuthors());
        System.out.println("Number of Total Authors: " + authorCounts);
        db.buildAuthorIndex();
        db.saveAuthorIndex();
        db.createGraphs();
        System.out.println("Parsing Finished");
    }
    
    public void startElement(String namespaceURI, String localName, String rawName, Attributes atts) throws SAXException {
        String k;
        if ((atts.getLength()>0) && ((k = atts.getValue("key"))!=null)) {
            key = k;
            recordTag = rawName;
            authorName = "";
        }
        preTag = rawName;
    }

    public void endElement(String namespaceURI, String localName, String rawName) throws SAXException {
        if (rawName.equals("author") || rawName.equals("editor")) {
            authors.add(authorName); 
            authorCounts++;
            authorName = "";
        }
        if (rawName.equals(recordTag)) {
            if(authors.size()>0)
                db.addPublication(new Publication(key, authors, year));
            authors.clear();
            /*
            String FILE_NAME = "graph" + year + ".txt";
            try {
                FileWriter fstream = new FileWriter(FILE_NAME, true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write(authors+"\n");
                out.close();
            }
            catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }
            */
        }
        preTag = null;
    }

    public void characters(char[] ch, int start, int length) throws SAXException {
        if(preTag!=null){  
            String content = new String(ch,start,length);
            if(preTag.equals("author")||preTag.equals("editor")){  
                authorName += content; 
            }else if(preTag.equals("year")){  
                year = Integer.parseInt(content);
            }
        }
    }

    private void Message(String mode, SAXParseException exception) {
        System.out.println(mode + " Line: " + exception.getLineNumber() + " URI: " + exception.getSystemId() + "\n" + " Message: " + exception.getMessage());
    }

    public void warning(SAXParseException exception) throws SAXException {
        Message("**Parsing Warning**\n", exception);
        throw new SAXException("Warning encountered");
    }

    public void error(SAXParseException exception) throws SAXException {
        Message("**Parsing Error**\n", exception);
        throw new SAXException("Error encountered");
    }

    public void fatalError(SAXParseException exception) throws SAXException {
        Message("**Parsing Fatal Error**\n", exception);
        throw new SAXException("Fatal Error encountered");
    }

    public static void main(String[] args) {
        String filename = null;
        
        for (int i = 0; i < args.length; i++) {
            filename = args[i];
        }
        if (filename == null) {
            System.err.println("Usage: java Parser [*.xml] [*.dtd]");
            System.exit(0);
        }
      
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(true);
	    SAXParser saxParser = spf.newSAXParser();
            XMLReader xmlReader = saxParser.getXMLReader();     
            xmlReader.setFeature("http://xml.org/sax/features/validation", true);
            GraphParser handler = new GraphParser();
            xmlReader.setContentHandler(handler);
            //saxParser.parse(new File(filename), handler);
            xmlReader.parse(filename);
        } catch (IOException e) {
            System.out.println("Error reading URI: " + e.getMessage());
        } catch (SAXException e) {
            System.out.println("Error in parsing: " + e.getMessage());
        } catch (ParserConfigurationException e) {
            System.out.println("Error in XML parser configuration: " + e.getMessage());
        }
   }
 
}   
