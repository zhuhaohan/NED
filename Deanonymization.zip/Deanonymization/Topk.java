import java.util.ArrayList;
import java.util.HashSet;
import java.util.PriorityQueue;

public class Topk {
	
	ArrayList<SubTree> data;
	SubTree query;
	int k;
	PriorityQueue<TreeDistance> topkINS;
	PriorityQueue<TreeDistance> topkFeature;
	
	public Topk(ArrayList<SubTree> data, SubTree query, int k){
		this.data = data;
		this.query = query;
		this.k = k;
		topkINS = new PriorityQueue<TreeDistance>();
		topkFeature = new PriorityQueue<TreeDistance>();
		for(int i = 0; i < data.size(); i++){
			SubTree target = data.get(i);
			
 			INS ins = new INS(target, query);
 			int ins_distance = ins.distance();
 			
			Feature feature = new Feature(target, query);
			int feature_distance = feature.distance();
			
			if(this.topkINS.isEmpty())
				this.topkINS.add(new TreeDistance(target, ins_distance));
			else {
				if(ins_distance < this.topkINS.peek().distance) {
					if(this.topkINS.size() >= this.k){
						this.topkINS.poll();
						this.topkINS.add(new TreeDistance(target, ins_distance));
					}
					else
						this.topkINS.add(new TreeDistance(target, ins_distance));
				}
			}

			if(this.topkFeature.isEmpty())
				this.topkFeature.add(new TreeDistance(target, feature_distance));
			else {
				if(feature_distance < this.topkFeature.peek().distance) {
					if(this.topkFeature.size() == this.k){
						this.topkFeature.poll();
						this.topkFeature.add(new TreeDistance(target, feature_distance));
					}
					else
						this.topkFeature.add(new TreeDistance(target, feature_distance));
				}
			}
			
		}
	}
	
	public HashSet<TreeDistance> INSresultSet(){
		HashSet<TreeDistance> resultSet = new HashSet<TreeDistance>();
		resultSet.addAll(topkINS);
		return resultSet;
	}
	
	public HashSet<TreeDistance> FeatureresultSet(){
		HashSet<TreeDistance> resultSet = new HashSet<TreeDistance>();
		resultSet.addAll(topkFeature);
		return resultSet;
	}
	
	public boolean inTopkINS(){
		while(!topkINS.isEmpty()){
			if(query.originalRootID == topkINS.poll().tree.originalRootID)
				return true;
		}
		return false;
	}
	
	public boolean inTopkFeature(){
		while(!topkFeature.isEmpty()){
			if(query.originalRootID == topkFeature.poll().tree.originalRootID)
				return true;
		}
		return false;
	}
	
}