import sys
import networkx as nx

for arg in sys.argv:
  year = arg

READ_FILE_NAME = "graph" + year + ".txt"
STAT_FILE_NAME = "stat" + year + ".txt"
SUB_FILE_NAME = "sub0Graph" + year + ".txt"
DC_FILE_NAME = "degreec" + year + ".txt"
BC_FILE_NAME = "betweennessc" + year + ".txt"
CC_FILE_NAME = "closenessc" + year + ".txt"

G=nx.read_edgelist(READ_FILE_NAME, nodetype=int)

nodes = G.number_of_nodes()
edges = G.number_of_edges()
connect = nx.is_connected(G)
ncomponents = nx.number_connected_components(G)

f1 = open(STAT_FILE_NAME, 'w')
f1.write("Graph - " + year + "\n\n")
f1.write("Number of nodes: " + str(nodes) + "\n")
f1.write("Number of edges: " + str(edges) + "\n")
f1.write("Connected ? : " + str(connect) + "\n")
f1.write("Number of components: " + str(ncomponents) + "\n\n")


subG = nx.connected_component_subgraphs(G)[0]
nx.write_edgelist(subG, SUB_FILE_NAME)
subnodes = subG.number_of_nodes()
subedges = subG.number_of_edges()
f1.write("Number of nodes for the largest connected subgraph: " + str(subnodes) + "\n")
f1.write("Number of edges for the largest connected subgraph: " + str(subedges) + "\n\n")
f1.close()

f2 = open(DC_FILE_NAME, 'w')
dc = nx.degree_centrality(subG)
for k in dc.keys():
	f2.write(str(k) + " : " + str(dc[k]) + "\n")
f2.close()

f3 = open(BC_FILE_NAME, 'w')
bc = nx.betweenness_centrality(subG)
for k in bc.keys():
	f3.write(str(k) + " : " + str(bc[k]) + "\n")
f3.close()

f4 = open(CC_FILE_NAME, 'w')
cc = nx.closeness_centrality(subG)
for k in cc.keys():
	f4.write(str(k) + " : " + str(cc[k]) + "\n")
f4.close()
