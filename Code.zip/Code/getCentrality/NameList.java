/*
 * @author Haohan Zhu
 */
import java.io.*;
import java.util.*;

public class NameList {
    /**
     * @param args the command line arguments
     * arg[0] is the list file
     */
    public static void main(String[] args) {
        HashMap name = new HashMap();
        String FILE_NAME = args[0];
        PriorityQueue<Author> list = new PriorityQueue<Author>();
        try{
            FileInputStream fstream = new FileInputStream("AuthorList.txt");
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            //Read File Line By Line
            while ((strLine = br.readLine()) != null)   {
                String[] values = strLine.split(": ");
                int id = Integer.parseInt(values[0]);
                String str = values[1];
                name.put(id, str);
            }
            in.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
                
        try{
            FileInputStream fstream = new FileInputStream(FILE_NAME);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            //Read File Line By Line
            while ((strLine = br.readLine()) != null)   {
                String[] values = strLine.split(" : ");
                int id = Integer.parseInt(values[0]);
                double centrality = Double.parseDouble(values[1]);
                list.add(new Author(id, centrality));
            }
            in.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
 
        for(int i = 0 ; i < 100 ; i++){
            Author author = list.poll();
            String OUTPUT_FILE_NAME = "Name-" + FILE_NAME;
            try{
                FileWriter fstream  = new FileWriter(OUTPUT_FILE_NAME, true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write(name.get(author.getID())+"\n");
                out.close();
            }
            catch (Exception e){
                System.err.println("Error: " + e.getMessage());
            }
        }
    }
    
}

