GraphParser.java
	Parse xml File
	Input:	dblp.xml
	Output:	Call DB class

DB.java
	Build Author Index, Generate Graphs
	Input:	Called by GraphParser.java
	Output:	"AuthorList.txt"
		"graph" + year + ".txt"		//EdgeList File

Publication.java
	Publication Class used by DB.java

graph.py
	Calculate Centrality
	Input:	"graph" + year + ".txt"
	Output:	"stat" + year + ".txt"
		"sub0Graph" + year + ".txt"
		"degreec" + year + ".txt"
		"betweennessc" + year + ".txt"
		"closenessc" + year + ".txt"

NameList.java
	Get Top 100 Author Names by Using Centrality Files
	Input:	"AuthorList.txt"
		"degreec" + year + ".txt"
		"betweennessc" + year + ".txt"
		"closenessc" + year + ".txt"
	Output:	"Name-" + FILE_NAME

Author.java
	Make Authors Comparable by Using Centralities

Preprocess.java
	Generate Neighbor List Files
	Input:	"graph" + year + ".txt"	
	Output:	"Neighbor-graph" + year + ".txt"

NodeSequence.java
	Generate NodeSequence Files
	Input:	"Neighbor-graph" + year + ".txt"
	Output:	query_id + "-NeighborList.txt";

NodeSequenceMeasure.java
	Measure Two NodeSequences

GraphSequence.java
	Generate GraphSequnece Files (Each Year Has One File)
	Input:	node_id
	Output:	year + "-" + node_id + "-SecondNeighborGraph.txt"



