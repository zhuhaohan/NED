import java.io.BufferedWriter;
import java.io.FileWriter;

public class PreKAT {

	public static void main(String[] args) throws Exception {

		String Folder_Name = "PGP";//DBLP,AMZN
		int p = 1;
		int k = 3;
		
		if(args.length == 2) {
			Folder_Name = args[0];
			p = Integer.parseInt(args[1]);
		}
		
		String Original_Graph_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/Edge.txt";
		String KAT_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT.txt";
		String Sparse_Graph_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/Sparse-" + p + ".txt";
		String Sparse_KAT_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT-Sparse-" + p + ".txt";
		String Perturbe_Graph_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/Permute-" + p + ".txt";
		String Perturbe_KAT_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT-Permute-" + p + ".txt";
		
		Graph g_original = new Graph();
		g_original.readFromEdeListFile(Original_Graph_File);
		System.out.println("Original Graph Reading Finish"); 

		FileWriter fstreamout_tree = new FileWriter(KAT_File);
		BufferedWriter out_tree = new BufferedWriter(fstreamout_tree);
		int maxKATSize = 0;
		for(int nodeID : g_original.nodeMap.keySet()){
			KAT kat = new KAT(nodeID, k, g_original, 0);
			out_tree.write(kat.toEdgeListSingleLine() + "\n");
			if(kat.size > maxKATSize)
				maxKATSize = kat.size;
		}
		out_tree.close();
		System.out.println("Max Size of KAT in the original graph: \t" + maxKATSize);
		System.out.println("# Nodes in the original graph: \t" + g_original.nodeMap.keySet().size());
		

		Graph g_sparse = new Graph();
		g_sparse.readFromEdeListFile(Sparse_Graph_File);
		System.out.println("Sparse Graph Reading Finish"); 

		FileWriter fstreamout_tree_sparse = new FileWriter(Sparse_KAT_File);
		BufferedWriter out_tree_sparse = new BufferedWriter(fstreamout_tree_sparse);
		int maxKAT_SparseSize = 0;
		for(int nodeID : g_sparse.nodeMap.keySet()){
			KAT kat = new KAT(nodeID, k, g_sparse, 0);
			out_tree_sparse.write(kat.toEdgeListSingleLine() + "\n");
			if(kat.size > maxKAT_SparseSize)
				maxKAT_SparseSize = kat.size;
		}
		out_tree_sparse.close();
		System.out.println("Max Size of KAT in the sparse graph: \t" + maxKAT_SparseSize);
		System.out.println("# Nodes in the sparse graph: \t" + g_sparse.nodeMap.keySet().size());


		Graph g_perturbe = new Graph();
		g_perturbe.readFromEdeListFile(Perturbe_Graph_File);
		System.out.println("Perturbate Graph Reading Finish"); 

		FileWriter fstreamout_tree_perturbe = new FileWriter(Perturbe_KAT_File);
		BufferedWriter out_tree_perturbe = new BufferedWriter(fstreamout_tree_perturbe);
		int maxKAT_PerturbeSize = 0;
		for(int nodeID : g_perturbe.nodeMap.keySet()){
			KAT kat = new KAT(nodeID, k, g_perturbe, 0);
			out_tree_perturbe.write(kat.toEdgeListSingleLine() + "\n");
			if(kat.size > maxKAT_PerturbeSize)
				maxKAT_PerturbeSize = kat.size;
		}
		out_tree_perturbe.close();
		System.out.println("Max Size of KAT in the perturbe graph: \t" + maxKAT_PerturbeSize);
		System.out.println("# Nodes in the perturbe graph: \t" + g_perturbe.nodeMap.keySet().size());

	}
}