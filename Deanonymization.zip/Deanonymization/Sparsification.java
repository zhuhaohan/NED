import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.PriorityQueue;
import java.util.Random;

public class Sparsification {
	
	public static void main(String[] args) throws Exception {

		String Folder_Name = "PGP";//DBLP,AMZN
		int size = 6523;//8000,8000
		int p = 1;
		
		if(args.length == 3) {
			Folder_Name = args[0];
			size = Integer.parseInt(args[1]);
			p = Integer.parseInt(args[2]);
		}
		
		
		String Edge_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/Edge.txt";
		String Sparse_Edge_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/Sparse-" + p + ".txt";
		
		
		PriorityQueue<Integer> edgeToBeRemoved = new PriorityQueue<Integer>();
		Random rand = new Random();
		
		while(edgeToBeRemoved.size() < p*0.01*size) {
			int r = rand.nextInt(size);
			if(!edgeToBeRemoved.contains(r))
				edgeToBeRemoved.add(r);
		}
		System.out.println("# lines to be removed:\t" + edgeToBeRemoved.size());
		
		int nextRemove = 0;
		if(!edgeToBeRemoved.isEmpty()){
			nextRemove = edgeToBeRemoved.poll();
		}
		
		FileReader fstreamin_edge = new FileReader(Edge_File);
		BufferedReader in_edge = new BufferedReader(fstreamin_edge);
		
		FileWriter fstreamout_sparse_edge = new FileWriter(Sparse_Edge_File);
		BufferedWriter out_edge = new BufferedWriter(fstreamout_sparse_edge);		
		
		String edge_str;
		int count = 0;
		while ((edge_str = in_edge.readLine()) != null) {
			if(nextRemove == count){
				count++;
				if(!edgeToBeRemoved.isEmpty()){
					nextRemove = edgeToBeRemoved.poll();
				}
				else{
					nextRemove = -1;
				}
			}
			else{
				count++;
				out_edge.write(edge_str + "\n");
			}
		}
		in_edge.close();
		out_edge.close();
	}
}
