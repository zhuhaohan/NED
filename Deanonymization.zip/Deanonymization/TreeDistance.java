public class TreeDistance implements Comparable<TreeDistance>{
	
	SubTree tree;
	int distance;
	
	public TreeDistance(SubTree tree, int distance){
		this.tree = tree;
		this.distance = distance;
	}

	@Override
	public int compareTo(TreeDistance o) {
		if(this.distance > o.distance)
			return -1;
		else if(this.distance < o.distance)
			return 1;
		else {
			if(this.tree.originalRootID > o.tree.originalRootID)
				return 1;
			else if (this.tree.originalRootID < o.tree.originalRootID)
				return -1;
			else
				return 0;
		}
	}

}
