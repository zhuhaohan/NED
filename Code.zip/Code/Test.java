/**
 *
 * @author Haohan Zhu
 */
import java.io.*;
import java.util.*;

public class Test {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int query_id1 = Integer.parseInt(args[0]);
	int query_id2 = Integer.parseInt(args[1]);

        NodeSequence node1 = new NodeSequence(query_id1);
        node1.readFromFile(query_id1);
	System.out.println("ID of Node is: " + node1.getNode_id());
	System.out.println("Paper of Node is: " + node1.number_paper());
	System.out.println("Length of Node Sequence is: " + node1.length());
	System.out.println("Node Sequence is: " + node1.number_paper_per_year());

	System.out.println();

        NodeSequence node2 = new NodeSequence(query_id2);
        node2.readFromFile(query_id2);
	System.out.println("ID of Node is: " + node2.getNode_id());
	System.out.println("Paper of Node is: " + node2.number_paper());
	System.out.println("Length of Node Sequence is: " + node2.length());
	System.out.println("Node Sequence is: " + node2.number_paper_per_year());

        System.out.println();
	NodeSequenceMeasure m  = new NodeSequenceMeasure(); 
	System.out.println("Distance 1 is: " + m.distance(node1, node2, 1));
	System.out.println("Distance 2 is: " + m.distance(node1, node2, 2));

	System.out.println();
	System.out.println("Start Generating Second Neighbor Graph");
	GraphSequence g = new GraphSequence(query_id1);
	g.generateEdgeLists();
	g.record();
	System.out.println("Finish Generating Second Neighbor Graph");
	
    }
}
