import networkx as nx
from pygraphviz import *

for x in range(1999, 2014):
	graph_file_name = `x` + '-630077-SecondNeighborGraph.txt'
	G = nx.read_edgelist(graph_file_name, nodetype=int)
	A = nx.to_agraph(G)
	A.layout()
	visualization_file_name = `x` + '-graph'
	A.draw(visualization_file_name, format='png',prog='fdp')


