public class Author implements Comparable<Author> {

    private int id;
    private double centrality;
    
    public Author(int id, double centrality){
        this.id = id;
        this.centrality = centrality;
    }
    
    public int getID(){
        return this.id;
    }
    
    public double getCentrality(){
        return this.centrality;
    }

    @Override
    public int compareTo(Author o) {
        if (this.centrality < o.centrality){
            return 1;
        }
        else if (this.centrality > o.centrality){
            return -1;
        }
        else{
            return 0;
        }
    }
}