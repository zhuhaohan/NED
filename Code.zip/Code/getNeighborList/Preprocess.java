/**
 *
 * @author Haohan Zhu
 */
import java.io.*;
import java.util.*;

public class Preprocess {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<Integer, HashSet> neighborList = new HashMap<Integer, HashSet>();
        String FILE_NAME = args[0];
        try{
            FileInputStream fstream = new FileInputStream(FILE_NAME);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            //Read File Line By Line
            while ((strLine = br.readLine()) != null)   {
                String[] values = strLine.split(" ");
                int id_1 = Integer.parseInt(values[0]);
                int id_2 = Integer.parseInt(values[1]);
                if (neighborList.containsKey(id_1)){
                    neighborList.get(id_1).add(id_2);
                }
                else{
                    neighborList.put(id_1, new HashSet());
                    neighborList.get(id_1).add(id_2);
                }
                if (neighborList.containsKey(id_2)){
                    neighborList.get(id_2).add(id_1);
                }
                else{
                    neighborList.put(id_2, new HashSet());
                    neighborList.get(id_2).add(id_1);
                }
            }
            in.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
        
        Set<Integer> keySet = neighborList.keySet();
        Iterator<Integer> iter = keySet.iterator();   

        String OUTPUT_FILE_NAME = "Neighbor-" + FILE_NAME;
        try{
            FileWriter fstream  = new FileWriter(OUTPUT_FILE_NAME, true);
            BufferedWriter out = new BufferedWriter(fstream);
            while(iter.hasNext()){
                int key = iter.next();
                HashSet neighbors = neighborList.get(key);
                Iterator inner_iter = neighbors.iterator();
                String neighborString = "";
                while(inner_iter.hasNext())
                    neighborString = neighborString + inner_iter.next() + ",";
                neighborString = key + ":" + neighborString;
                out.write(neighborString.substring(0,neighborString.length()-1) + "\n");
            } 
            out.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
    }
    
}