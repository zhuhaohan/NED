import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

public class Perturbation {
	
	public static void main(String[] args) throws Exception {

		String Folder_Name = "PGP";//DBLP,AMZN
		int size = 6523;//8000,8000
		int p = 1;
		
		if(args.length == 3) {
			Folder_Name = args[0];
			size = Integer.parseInt(args[1]);
			p = Integer.parseInt(args[2]);
		}
		
		String Sparse_Edge_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/Sparse-" + p + ".txt";
		String Perturbe_Edge_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "/Permute-" + p + ".txt";
		
		FileReader fstreamin_sparse_edge = new FileReader(Sparse_Edge_File);
		BufferedReader in_edge = new BufferedReader(fstreamin_sparse_edge);
		
		HashMap<Integer, HashSet<Integer>> nodeMap = new HashMap<Integer, HashSet<Integer>>();
		int maxNodeID = 0;
		
        String strLine;
        while ((strLine = in_edge.readLine()) != null) {
        	String[] values = strLine.split("\t");
            int src = Integer.parseInt(values[0]);
            int dst = Integer.parseInt(values[1]);
            if(!nodeMap.containsKey(src))
            	nodeMap.put(src, new HashSet<Integer>());
            if(!nodeMap.containsKey(dst))
            	nodeMap.put(dst, new HashSet<Integer>());
            nodeMap.get(src).add(dst);
            nodeMap.get(dst).add(src);
            if(src > maxNodeID)
            	maxNodeID = src;
            if(dst > maxNodeID)
            	maxNodeID = dst;
        }
        in_edge.close();
        
        int count = 0;
		Random rand = new Random();
		
		while(count < Math.ceil(size*0.01*p)) {
			int r_1 = rand.nextInt(maxNodeID);
			int r_2= rand.nextInt(maxNodeID);
			int r_src = -1;
			int r_dst = -1;
			if(r_1 < r_2) {
				r_src = r_1;
				r_dst = r_2;
			}
			else if (r_2 < r_1) {
				r_src = r_2;
				r_dst = r_1;				
			}
			if(nodeMap.containsKey(r_src) && nodeMap.containsKey(r_dst)) {
				if(!nodeMap.get(r_src).contains(r_dst)) {
					nodeMap.get(r_src).add(r_dst);
					count++;
				}
			}	
		}
		System.out.println("# lines to be added:\t" + count);
		
		FileWriter fstreamout_perturbe_edge = new FileWriter(Perturbe_Edge_File);
		BufferedWriter out_edge = new BufferedWriter(fstreamout_perturbe_edge);		
		
		for(int src : nodeMap.keySet()) {
			for(int dst : nodeMap.get(src)) {
				if(src < dst)
					out_edge.write(src + "\t" + dst + "\n");
			}
		}
		out_edge.close();
	}
}
