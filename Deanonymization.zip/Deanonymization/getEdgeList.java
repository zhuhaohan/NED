import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashSet;

public class getEdgeList {

	public static void main(String[] args) throws Exception {

		String Folder_Name = "PGP";
		int k = 3;
		
		if(args.length == 2) {
			Folder_Name = args[0];
			k = Integer.parseInt(args[1]);
		}
		
		String Node_File = "/scratch/zhu/cs/Node-" + k + "-" + Folder_Name + ".txt";
		FileReader fstreamin_node = new FileReader(Node_File);
		BufferedReader in_node = new BufferedReader(fstreamin_node);
		HashSet<Integer> node_set = new HashSet<Integer>();
		String node_str;
	    while ((node_str = in_node.readLine()) != null) {
	    	node_set.add(Integer.parseInt(node_str));
	    }
	    in_node.close();

		String Original_Graph_File = "/scratch/zhu/graph/" + Folder_Name + "/sortedData.txt";
		FileReader fstreamin_graph = new FileReader(Original_Graph_File);
		BufferedReader in_graph = new BufferedReader(fstreamin_graph);
		String graph_str;
		
		String Edge_File = "/scratch/zhu/cs/Edge-" + k + "-" + Folder_Name + ".txt";	
		FileWriter fstreamout_edge = new FileWriter(Edge_File);
		BufferedWriter out_edge = new BufferedWriter(fstreamout_edge);
		
        while ((graph_str = in_graph.readLine()) != null) {
        	if(graph_str.charAt(0) != '#'){ // All lines starting with '#' are ignored
            	String[] values = graph_str.split("\\s"); // The graph file is an edge list
            	int src = Integer.parseInt(values[0]);
            	int dst = Integer.parseInt(values[1]);
            	if(node_set.contains(src) && node_set.contains(dst))
            		out_edge.write(src + "\t" + dst + "\n");
        	}
        }
        in_graph.close();
        out_edge.close();
		
	}
}