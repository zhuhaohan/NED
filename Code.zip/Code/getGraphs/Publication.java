import java.util.*;

public class Publication {
    private String key;
    private LinkedList<String> authors;	// or editors
    private int year;

    public Publication(String key, LinkedList<String> authors, int year) {
        this.authors = new LinkedList<String>();
        for(int i = 0; i < authors.size(); i++)
            this.authors.add(authors.get(i));
        this.key = key;
        this.year  = year;
    }
    
    public String getPublicationKey() {
        return key;
    }
        
    public LinkedList<String> getAuthors() {
        return authors;
    }
    
    public int getYear() {
        return year;
    }
    
    public String toString(){
        return key + ": " + year + ": " + authors;
    }

}