import java.util.*;
import java.io.*;

public class DB {
    private HashMap db;
    private HashSet Authors;
    private LinkedList AuthorIndex;
    private HashSet Publications;

    public DB() {
        db = new HashMap<String, Publication>();
        Authors = new HashSet<String>();
        AuthorIndex = new LinkedList<Integer>();
        Publications = new HashSet<String>();
    }
    
    public void addPublication(Publication p) {
        db.put(p.getPublicationKey(), p);
        Authors.addAll(p.getAuthors());
        Publications.add(p.getPublicationKey());
    }
        
    public int sizeOfAuthors() {
        return Authors.size();
    }
    
    public int sizeofPublications() {
        return Publications.size();
    }
    
    public void buildAuthorIndex(){
        Iterator iter = Authors.iterator();
        while(iter.hasNext()){
            AuthorIndex.add(iter.next());
        }
        System.out.println("Author List Built");
    }

    public void saveAuthorIndex(){
        String FILE_NAME = "AuthorList.txt";
            try {
                for(int i = 0; i < AuthorIndex.size(); i++){
                    FileWriter fstream = new FileWriter(FILE_NAME, true);
                    BufferedWriter out = new BufferedWriter(fstream);
                    out.write(i + ": " + AuthorIndex.get(i) + "\n");
                    out.close();
                    if(i%100000 == 0)
                        System.out.println(i);
                }
            }
            catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }
         System.out.println("Author List Saved");
    }

    public void createGraphs(){
        Iterator<Publication> iter = db.values().iterator();
        while(iter.hasNext()){
            Publication p = iter.next();
            String FILE_NAME = "graph" + p.getYear() + ".txt";
            try {
                FileWriter fstream = new FileWriter(FILE_NAME, true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write(createEdges(p.getAuthors()));
                out.close();
            }
            catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }
        }
        System.out.println("Graphs Created");
    }

    private String createEdges(LinkedList authorNames){
        LinkedList authorIndex = new LinkedList();
        String result = "";
        for(int i = 0; i < authorNames.size(); i++){
            int index  = AuthorIndex.indexOf(authorNames.get(i));
            if(index != -1)
                authorIndex.add(index);
        }
        if(authorIndex.size() > 0){
            for(int i = 0; i < authorIndex.size(); i++){
                for(int j = i+1; j < authorIndex.size(); j++){
                    result += authorIndex.get(i) + " " + authorIndex.get(j) + "\n";
                }
            }
        }
        return result;
    }
}
