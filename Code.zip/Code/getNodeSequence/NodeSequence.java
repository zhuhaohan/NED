import java.util.*;
import java.io.*;

public class NodeSequence {
   
    private int node_id;
    private LinkedList<HashSet> neighbors;

    public NodeSequence(int node_id) {
        this.node_id = node_id;
        this.neighbors = new LinkedList<HashSet>();
        for(int year = 1936; year <= 2014; year++){
	    neighbors.add(new HashSet());
	}
    }

    public int getNode_id() {
        return this.node_id;
    }

    public LinkedList getNeighbors() {
        return this.neighbors;
    }

    public HashSet getNeighborsByYear(int index) {
        return this.neighbors.get(index);
    }

    public LinkedList<HashSet> getNeighborSeq() {
	LinkedList<HashSet> neighborSeq = new LinkedList<HashSet>();
        for(int i = 0; i < this.neighbors.size(); i++){
            if(this.neighbors.get(i).size() > 0){
                neighborSeq.add(this.neighbors.get(i));
	    }
        }
        return neighborSeq;
    }

    public int length() {
        int length = 0;
        for(int i = 0; i < this.neighbors.size(); i++){
            if(this.neighbors.get(i).size() > 0)
                length++;
        }
        return length;
    }

    public int number_paper() {
        int count = 0;
        for(int i = 0; i < this.neighbors.size(); i++){
            count += this.neighbors.get(i).size();
        }
        return count;
    }

    public LinkedList number_paper_per_year() {
        LinkedList count_per_year = new LinkedList();
        for(int i = 0; i < this.neighbors.size(); i++){
            if(this.neighbors.get(i).size() > 0)
                count_per_year.add(this.neighbors.get(i).size());
        }
        return count_per_year;
    }
        
    public void addNeighbor(int year, HashSet neighbor_year){
        this.neighbors.get(year-1936).addAll(neighbor_year);
    }

    public void readFromFile(int query_id){
	String inputFile = query_id + "-NeighborList.txt";
	File f = new File(inputFile);
	if(!f.exists()) {
	    generateFile(query_id);
	}
        try{
            FileInputStream fstream = new FileInputStream(inputFile);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            int year = 0;
            while ((strLine = br.readLine()) != null)   {
		if(!strLine.equals("")){
                    String[] values = strLine.split(",");
                    HashSet neighborSet = new HashSet();
                    for(int i = 0; i < values.length; i++){
		        neighborSet.add(Integer.parseInt(values[i]));
		    }
                    this.neighbors.get(year).addAll(neighborSet);
		}
		year++;
            }
            in.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
    }

    public boolean generateFile(int query_id){
	String outputFile = query_id + "-NeighborList.txt";
	File f = new File(outputFile);
	if(f.exists()) {
	    return false;
	}        
	else {
	    String FILE_NAME = "";
            String neighbor = "";
            for(int i = 1936; i <= 2014; i++){
                FILE_NAME = "Neighbor-graph" + i + ".txt";
                neighbor = "";
                try{
                    FileInputStream fstream = new FileInputStream(FILE_NAME);
                    DataInputStream in = new DataInputStream(fstream);
                    BufferedReader br = new BufferedReader(new InputStreamReader(in));
                    String strLine;
                    while ((strLine = br.readLine()) != null)   {
                        String[] values = strLine.split(":");
                        int id = Integer.parseInt(values[0]);
                        String id_neighbor = values[1];
                        if (query_id==id){
                            neighbor = id_neighbor;
                        }
                    }
                    in.close();
                }
                catch (Exception e){
                     System.err.println("Error: " + e.getMessage());
                }
                try{
                    FileWriter fstream  = new FileWriter(outputFile, true);
                    BufferedWriter out = new BufferedWriter(fstream);
                    out.write(neighbor + "\n");
                    out.close();
                }
                catch (Exception e){
                    System.err.println("Error: " + e.getMessage());
                }
            }
	    return true;
        }
    }

}
