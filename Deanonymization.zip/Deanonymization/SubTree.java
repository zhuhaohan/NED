import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class SubTree {
	
	int originalRootID;
	HashMap<Integer, Node_SubTree> nodeMap;
	Node_SubTree root;
	int k; // Record number of levels
	HashMap<Integer, ArrayList<Node_SubTree>> AT; // Record node array per level
	int[] maxDegree; // Record maximal degree of the nodes per level
	
	public SubTree(String OneLine){
		this.nodeMap = new HashMap<Integer, Node_SubTree>();
		this.originalRootID = 0;
		this.k = 0;
		this.AT = new HashMap<Integer, ArrayList<Node_SubTree>>();
		this.maxDegree = new int[this.k+1];
		int rootID = 0;
		String[] str = OneLine.split(";");
		
		String[] RIDstr = str[0].split("\t");
		this.originalRootID = Integer.parseInt(RIDstr[1]);
		
		String[] kstr = str[1].split("\t");
		this.k = Integer.parseInt(kstr[1]);
		
		this.maxDegree = new int[this.k+1];

		String[] maxDegreestr = str[2].split("\t");
		String[] degrees = maxDegreestr[1].split(",");
		for(int i = 0; i <= k; i++) {
			this.AT.put(i, new ArrayList<Node_SubTree>());
			this.maxDegree[i] = Integer.parseInt(degrees[i]);
		}
		
		String[] rootIDstr = str[3].split("\t");
		rootID = Integer.parseInt(rootIDstr[1]);
		
		for(int i = 4; i < str.length; i++){
			String[] edgePair = str[i].split("\t");
			int src = Integer.parseInt(edgePair[0]);
			int dst = Integer.parseInt(edgePair[1]);
			if(!nodeMap.containsKey(src)){
				this.nodeMap.put(src, new Node_SubTree(src));
			}
			if(!nodeMap.containsKey(dst)){
				this.nodeMap.put(dst, new Node_SubTree(dst, this.nodeMap.get(src)));
			}			
			this.nodeMap.get(src).addChild(this.nodeMap.get(dst));
		}
		
		this.root = this.nodeMap.get(rootID);
		for(int id : this.nodeMap.keySet()) {
			this.AT.get(this.nodeMap.get(id).level).add(this.nodeMap.get(id));
		}

	}
	
	public int size(){
		return this.nodeMap.keySet().size();
	}
	
	public HashSet<Node_SubTree> getNodeSet(){
		HashSet<Node_SubTree> nodeSet = new HashSet<Node_SubTree>();
		for(int n : this.nodeMap.keySet()){
			nodeSet.add(nodeMap.get(n));
		}
		return nodeSet;
	}
	
	public String toString(){
		String str = "K = " + this.k + "\n";
		for(int i = 0; i <= this.k; i++) {
			str += "Level " + i + ":\t";
			for(int j = 0; j < this.AT.get(i).size(); j++)
				str += this.AT.get(i).get(j).toString() + ",";
			if(this.AT.get(i).size() > 0)
				str = str.substring(0, str.length()-1);
			str += "\n";
		}
		return str.substring(0, str.length()-1);
	}
	
	public double[][] matrix(){
		
		double[][] matrix = new double[this.nodeMap.keySet().size()][this.nodeMap.keySet().size()];
		for(int i = 0; i < matrix.length; i++)
			for(int j = 0; j < matrix[i].length; j++)
				matrix[i][j] = 0.0;
		
		for(int i = 0; i <= k; i++) {
			for(int j = 0; j < this.AT.get(i).size(); j++) {
				int src = this.AT.get(i).get(j).id - this.root.id;
				for(int k = 0; k < this.AT.get(i).get(j).children.length; k++) {
					int dst = this.AT.get(i).get(j).children[k].id - this.root.id;
					matrix[src][dst] = 1.0;
					//this.matrix[dst][src] = 1.0;
				}
			}
		}
		
		return matrix;
	}
	
}