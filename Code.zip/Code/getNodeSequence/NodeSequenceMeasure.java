import java.util.*;

public class NodeSequenceMeasure {
   
    public double distance (NodeSequence node1, NodeSequence node2, int type) {

        LinkedList<HashSet> n1 = node1.getNeighborSeq();
        LinkedList<HashSet> n2 = node2.getNeighborSeq();

        double[][] distance = new double[n1.size()][n2.size()];
        distance[0][0] = cost(n1.get(0), n2.get(0), type);  
        for (int i = 1; i < n1.size(); i++)
            distance[i][0] = distance[i-1][0] + cost(n1.get(i), n2.get(0), type);
        for (int j = 1; j < n2.size(); j++)
            distance[0][j] = distance[0][j-1] + cost(n1.get(0), n2.get(j), type);
        for (int i = 1; i < n1.size(); i++)
            for (int j = 1; j < n2.size(); j++){
                distance[i][j] = minimum(distance[i-1][j], distance[i][j-1], distance[i-1][j-1]) + 
				 cost(n1.get(i), n2.get(j), type);
        }                              
        return distance[node1.length()-1][node2.length()-1];
    }

    private double minimum(double a, double b, double c){
        return Math.min(Math.min(a, b), c);
    }
    
    private double cost(HashSet p, HashSet q, int type){
        if(type == 1)
	    return cost1(p, q);
	else
	    return cost2(p, q);
    }
    
    public double cost1(HashSet p, HashSet q){
    	return Math.abs(p.size() - q.size());
    }

    public double cost2(HashSet p, HashSet q){
        HashSet union = new HashSet(p);
        union.addAll(q);
        HashSet intersection = new HashSet(q);
        intersection.retainAll(p);
	return (union.size()-intersection.size())/union.size();
    }

}
