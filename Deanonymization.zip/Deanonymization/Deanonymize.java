import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Deanonymize {

	public static void main(String[] args) throws IOException {
    	
		String Folder_Name = "PGP";//DBLP,AMZN
		int QueryTicker = 0;
		int step = 1;
		
		if(args.length == 3) {
			Folder_Name = args[0];
			QueryTicker = Integer.parseInt(args[1]);
			step = Integer.parseInt(args[2]);
		}

		int mod = 10;

		if(QueryTicker == 0) {
			String QueryType = "Naive";
			String Training = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT.txt";
			String Testing = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT.txt";
			String Result_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "-" + QueryType + "-Results.txt";
			
			FileWriter fstreamout_result = new FileWriter(Result_File);
			BufferedWriter out_result = new BufferedWriter(fstreamout_result);
			out_result.write("Dataset" + "\t" + "Type" + "\t"  + "Top-K" + "\t" + "Dataset" + 
							"\t" + "Query" + "\t" + "Feature" + "\t" + "NED" + "\n");
		
			ArrayList<SubTree> data = new ArrayList<SubTree>();
			ArrayList<SubTree> query = new ArrayList<SubTree>();
        
			FileReader training_tree_in = new FileReader(Training);
			BufferedReader training_in = new BufferedReader(training_tree_in);
			String training_strLine;
			while ((training_strLine = training_in.readLine()) != null) {
				SubTree st = new SubTree(training_strLine);
				data.add(st);
			}
			training_in.close();
        
			int counter = 0;
			FileReader testing_tree_in = new FileReader(Testing);
			BufferedReader testing_in = new BufferedReader(testing_tree_in);
			String testing_strLine;
			while ((testing_strLine = testing_in.readLine()) != null) {
				if(counter % mod == 0) {
					SubTree st = new SubTree(testing_strLine);
					query.add(st);
				}		
				counter++;
			}
			testing_in.close();

			for(int topk = 1; topk < 10; topk++){
				int INS = 0;
				int Feature = 0;
				for(int i = 0; i < query.size(); i++) {
					Topk result = new Topk(data, query.get(i), topk*step);
					if(result.inTopkINS())
						INS++;
					if(result.inTopkFeature())
						Feature++;
				}
				out_result.write(Folder_Name + "\t" + QueryType + "\t" + topk + "\t" + data.size() + 
						"\t" + query.size() + "\t" + Feature + "\t" + INS + "\n");
				out_result.flush();
			}			
			out_result.close(); 
		}
		else if(QueryTicker == 1) {
			String QueryType = "Sparse";
			
			for(int p = 1; p < 10; p++) {
			
			String Training = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT.txt";
			String Testing = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT-Sparse-" + p + ".txt";
			String Result_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "-" + QueryType + "-" + p + "-Results.txt";
			
			FileWriter fstreamout_result = new FileWriter(Result_File);
			BufferedWriter out_result = new BufferedWriter(fstreamout_result);
			out_result.write("Dataset" + "\t" + "Type" + "\t"  + "Top-K" + "\t" + "Dataset" + 
					"\t" + "Query" + "\t" + "Feature" + "\t" + "NED" + "\n");
		
			ArrayList<SubTree> data = new ArrayList<SubTree>();
			ArrayList<SubTree> query = new ArrayList<SubTree>();
        
			FileReader training_tree_in = new FileReader(Training);
			BufferedReader training_in = new BufferedReader(training_tree_in);
			String training_strLine;
			while ((training_strLine = training_in.readLine()) != null) {
				SubTree st = new SubTree(training_strLine);
				data.add(st);
			}
			training_in.close();
        
			int counter = 0;
			FileReader testing_tree_in = new FileReader(Testing);
			BufferedReader testing_in = new BufferedReader(testing_tree_in);
			String testing_strLine;
			while ((testing_strLine = testing_in.readLine()) != null) {
				if(counter % mod == 0) {
					SubTree st = new SubTree(testing_strLine);
					query.add(st);
				}		
				counter++;
			}
			testing_in.close();

			for(int topk = 1; topk < 10; topk++){
				int INS = 0;
				int Feature = 0;
				for(int i = 0; i < query.size(); i++) {
					Topk result = new Topk(data, query.get(i), topk*step);
					if(result.inTopkINS())
						INS++;
					if(result.inTopkFeature())
						Feature++;
				}
				out_result.write(Folder_Name + "\t" + QueryType + "\t" + topk + "\t" + data.size() + 
						"\t" + query.size() + "\t" + Feature + "\t" + INS + "\n");
				out_result.flush();
			}			
			out_result.close(); 
			
			}
		}
		else if(QueryTicker == 2) {
			String QueryType = "Permute";
			
			for(int p = 1; p < 10; p++) {
			
			String Training = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT.txt";
			String Testing = "/scratch/zhu/Deanonymization/" + Folder_Name + "/KAT-Permute-" + p + ".txt";
			String Result_File = "/scratch/zhu/Deanonymization/" + Folder_Name + "-" + QueryType + "-" + p + "-Results.txt";
			
			FileWriter fstreamout_result = new FileWriter(Result_File);
			BufferedWriter out_result = new BufferedWriter(fstreamout_result);
			out_result.write("Dataset" + "\t" + "Type" + "\t"  + "Top-K" + "\t" + "Dataset" + 
					"\t" + "Query" + "\t" + "Feature" + "\t" + "NED" + "\n");
		
			ArrayList<SubTree> data = new ArrayList<SubTree>();
			ArrayList<SubTree> query = new ArrayList<SubTree>();
        
			FileReader training_tree_in = new FileReader(Training);
			BufferedReader training_in = new BufferedReader(training_tree_in);
			String training_strLine;
			while ((training_strLine = training_in.readLine()) != null) {
				SubTree st = new SubTree(training_strLine);
				data.add(st);
			}
			training_in.close();
        
			int counter = 0;
			FileReader testing_tree_in = new FileReader(Testing);
			BufferedReader testing_in = new BufferedReader(testing_tree_in);
			String testing_strLine;
			while ((testing_strLine = testing_in.readLine()) != null) {
				if(counter % mod == 0) {
					SubTree st = new SubTree(testing_strLine);
					query.add(st);
				}		
				counter++;
			}
			testing_in.close();

			for(int topk = 1; topk < 10; topk++){
				int INS = 0;
				int Feature = 0;
				for(int i = 0; i < query.size(); i++) {
					Topk result = new Topk(data, query.get(i), topk*step);
					if(result.inTopkINS())
						INS++;
					if(result.inTopkFeature())
						Feature++;
				}
				out_result.write(Folder_Name + "\t" + QueryType + "\t" + topk + "\t" + data.size() + 
						"\t" + query.size() + "\t" + Feature + "\t" + INS + "\n");
				out_result.flush();
			}			
			out_result.close();
			
			}
			
		}
		
	}
}
