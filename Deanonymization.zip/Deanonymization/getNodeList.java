import java.io.BufferedWriter;
import java.io.FileWriter;

public class getNodeList {

	public static void main(String[] args) throws Exception {

		String Folder_Name = "PGP";
		int k = 3;
		
		if(args.length == 2) {
			Folder_Name = args[0];
			k = Integer.parseInt(args[1]);
		}
		
		int shreshold = 500;
		
		String Original_Graph_File = "/scratch/zhu/graph/" + Folder_Name + "/sortedData.txt";
		Graph g = new Graph();
		g.readFromEdeListFile(Original_Graph_File);
		System.out.println("Graph Reading Finish"); 

		String Node_File = "/scratch/zhu/cs/Node-" + k + "-" + Folder_Name + ".txt";	
		FileWriter fstreamout_node = new FileWriter(Node_File);
		BufferedWriter out_node = new BufferedWriter(fstreamout_node);
		
		int count = 0;
		for(int nodeID : g.nodeMap.keySet()){
			count++;
			if(count > 0 && count % 1000 == 0)
				System.out.println(count + " Nodes Have Been Processed");
			
			KAT kat = new KAT(nodeID, k, g, 0);			

			if(kat.size < shreshold) {
				out_node.write(nodeID + "\n");
			}
		}
		out_node.close();
	}
}