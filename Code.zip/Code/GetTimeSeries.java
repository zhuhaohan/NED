/**
 *
 * @author Haohan Zhu
 */
import java.io.*;
import java.util.*;

public class GetTimeSeries {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

for(int query_id = 0; query_id <= 1298390; query_id++){
        
        //int query_id = Integer.parseInt(args[0]);
        String FILE_NAME = "";
        String neigbor = "";
        for(int i = 1936; i <= 2014; i++){
            FILE_NAME = "Neighbor-graph" + i + ".txt";
            neigbor = "";
            try{
                FileInputStream fstream = new FileInputStream(FILE_NAME);
                DataInputStream in = new DataInputStream(fstream);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                String strLine;
                //Read File Line By Line
                while ((strLine = br.readLine()) != null)   {
                    String[] values = strLine.split(":");
                    int id = Integer.parseInt(values[0]);
                    String id_neighbor = values[1];
                    if (query_id==id){
                        neigbor = id_neighbor;
                    }
                }
                in.close();
            }
            catch (Exception e){
                System.err.println("Error: " + e.getMessage());
            }

            String OUTPUT_FILE_NAME = query_id + "-NeighborList.txt";
            try{
                FileWriter fstream  = new FileWriter(OUTPUT_FILE_NAME, true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write(neigbor + "\n");
                out.close();
            }
            catch (Exception e){
                 System.err.println("Error: " + e.getMessage());
            }
        }

if(query_id%10000 == 0){System.out.println(query_id + "authors have been proccessed.");}
}

    }
}
