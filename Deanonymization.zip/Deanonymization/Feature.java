import java.util.ArrayList;

public class Feature {
	
	int[] vectorx;
	int[] vectory;
	
	public Feature(SubTree input_tx, SubTree input_ty){

		this.vectorx = new int[input_tx.k*2];
		this.vectory = new int[input_ty.k*2];
		
		for(int i = 0; i < input_tx.k; i++){
			ArrayList<Node_SubTree> tempNodes = input_tx.AT.get(i);
			int degreeSUM = 0;
			for(int j = 0; j < tempNodes.size(); j++){
				degreeSUM += tempNodes.get(j).children.length;
			}
			int degreeAVE = 0;
			if(tempNodes.size()!=0)
				degreeAVE = degreeSUM / tempNodes.size();
			this.vectorx[i*2 + 0] = degreeSUM;
			this.vectorx[i*2 + 1] = degreeAVE;
		}
		
		for(int i = 0; i < input_ty.k; i++){
			ArrayList<Node_SubTree> tempNodes = input_ty.AT.get(i);
			int degreeSUM = 0;
			for(int j = 0; j < tempNodes.size(); j++){
				degreeSUM += tempNodes.get(j).children.length;
			}
			int degreeAVE = 0;
			if(tempNodes.size()!=0)
				degreeAVE = degreeSUM / tempNodes.size();
			this.vectory[i*2 + 0] = degreeSUM;
			this.vectory[i*2 + 1] = degreeAVE;
		}
		
	}
	
	public int distance(){
		int d = 0;
		for(int i = 0; i < this.vectorx.length; i++){
			d += (this.vectorx[i] - this.vectory[i])*(this.vectorx[i] - this.vectory[i]);
		}
		return d;
	}

}