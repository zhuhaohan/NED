public class Node_SubTree implements Comparable<Node_SubTree>{
	
	int id;
	Node_SubTree parent;
	Node_SubTree[] children;
	int level;
	CanonicalLabel cLabel;
	
	// Create a root node
	public Node_SubTree(int input_id){
		this.id = input_id;
		this.parent = null;
		this.children = new Node_SubTree[0];
		this.level = 0;
		this.cLabel = new CanonicalLabel();
	}
	
	// Create a leaf node
	public Node_SubTree(int input_id, Node_SubTree input_parent){
		this.id = input_id;
		this.parent = input_parent;
		this.children = new Node_SubTree[0];
		this.level = input_parent.level + 1;
		this.cLabel = new CanonicalLabel();
	}
	
	public void addChild(Node_SubTree newChild){
		Node_SubTree[] tmp = new Node_SubTree[this.children.length + 1];
		for(int i = 0; i < this.children.length; i++)
			tmp[i] = this.children[i];
		tmp[this.children.length] = newChild;
		this.children = tmp.clone();
	}

	public String toString(){
		String str = this.id + "<" + this.cLabel.label + ">(";
		for(int i = 0; i < this.children.length - 1; i++) {
			str += this.children[i].id + "<" + this.children[i].cLabel.label + ">" + ",";
		}
		if(this.children.length > 0)
			str += this.children[this.children.length - 1].id + "<" + this.children[this.children.length - 1].cLabel.label + ">" + ")";
		else
			str += ")";
		return str;
	}

	@Override
	public int compareTo(Node_SubTree other) {
		return this.cLabel.compareTo(other.cLabel);
	}
}