import java.util.*;
import java.io.*;

public class GraphSequence {
   
    private int node_id;
    private LinkedList<HashSet> neighbors;
    private LinkedList<String> edgelists;

    public GraphSequence(int node_id) {
	NodeSequence node = new NodeSequence(node_id);
        node.readFromFile(node_id);        
	this.node_id = node.getNode_id();
        this.neighbors = node.getNeighbors();
	this.edgelists = new LinkedList<String>();
	for(int i = 0; i < this.neighbors.size(); i++){
	    String node_id_string = node_id + "";
	    this.edgelists.add(generateEdges(node_id_string, this.neighbors.get(i)));
	}
    }

    public void record(){
	for(int i = 0; i < this.edgelists.size(); i++){
	    if(!this.edgelists.get(i).equals("")){
	        try{
		    int year = i + 1936;
		    String FILE_NAME = year + "-" + this.node_id + "-SecondNeighborGraph.txt";
	            FileWriter fstream  = new FileWriter(FILE_NAME);
	            BufferedWriter out = new BufferedWriter(fstream);
		    out.write(this.edgelists.get(i));
                    out.close();
		}
		catch (Exception e){
	    	    System.err.println("Error: " + e.getMessage());
		}
	    }
	}
    }

    public void generateEdgeLists(){
	for(int i = 0; i < this.edgelists.size(); i++){
	    String edges = "";
            if(this.neighbors.get(i).size() > 0){
		LinkedList firstNeighbor = new LinkedList();
		firstNeighbor.addAll(this.neighbors.get(i));
		LinkedList<HashSet> secondNeighbor = new LinkedList();
		secondNeighbor = getSecondNeighbor(firstNeighbor, i);
		for (int j = 0; j < firstNeighbor.size(); j++){
			edges += generateEdges(firstNeighbor.get(j).toString(), secondNeighbor.get(j));
		}
	    }
	    this.edgelists.set(i, this.edgelists.get(i) + edges);
        }
    }

    public String generateEdges(String firstNeighbor, HashSet secondNeighbor){
	String record = "";	
	Iterator iter = secondNeighbor.iterator();
	while(iter.hasNext()) {
	    record += firstNeighbor + " " + iter.next() + "\n";
	}
	return record;
    }

    public LinkedList<HashSet> getSecondNeighbor(LinkedList<Integer> firstNeighbor, int year) {
	LinkedList<HashSet> secondNeighbor = new LinkedList<HashSet>();
	for(int i = 0; i < firstNeighbor.size(); i++){
	    secondNeighbor.add(new HashSet());
	    secondNeighbor.get(i).addAll(queryNeighbor(firstNeighbor.get(i), year+1936));
	}     
	return secondNeighbor;
    }

    public HashSet queryNeighbor(int query_id, int year){
	String FILE_NAME = "Neighbor-graph" + year + ".txt";
        String neigbor = "";
        try{
	    FileInputStream fstream = new FileInputStream(FILE_NAME);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            while ((strLine = br.readLine()) != null)   {
            	String[] values = strLine.split(":");
            	int id = Integer.parseInt(values[0]);
            	String id_neighbor = values[1];
            	if (query_id==id){
                    neigbor = id_neighbor;
                }
            }
            in.close();
	}
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
	HashSet neighborSet = new HashSet();
	if(!neigbor.equals("")){
            String[] values = neigbor.split(",");       
            for(int i = 0; i < values.length; i++){
		neighborSet.add(Integer.parseInt(values[i]));
	    }
	}
	return neighborSet;
    }

}
